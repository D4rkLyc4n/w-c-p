<?php
    $host = $_SERVER['HTTP_X_FORWARDED_HOST'] ?? ''; // Get the X-Forwarded-Host header value
?>

<html>
<head>
    <title>Web cache poisoning</title>
</head>
<body>
    <center>
        <h3>Hello_world</h3>
        <img src="<?php echo $host; ?>/w-c-p/Hello_Hello.png">
    </center>
</body>
</html>
